package p1;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HiServlet extends HttpServlet {
    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse res) {
	//## A very bad idea for generating output...
	String msgPluslink = "<html><body><h3>Hi from servlet</h3><p><a href = " +
	    getServletContext().getContextPath() +   //## returns the string /hi3, the WAR file's name
	    "/hiA.html>" + "Top-level hi" +          //## link is now: /hi3/hiTop.html
	    "</a></p></body></html>";
	try {
	    res.getOutputStream().println(msgPluslink);
	}
	catch(Exception e) { }
    }
}
